# Publishing this repo to github.com/supertatsis (delete this file after)

## Option A — browser only
1. Go to https://github.com/new → name: `flora-mcp-starter`, Public, no README/licence (they're included). Create.
2. On the empty repo page click **uploading an existing file**, drag the whole folder contents in, commit.

## Option B — terminal
```bash
cd flora-mcp-starter
rm PUSH-TO-GITHUB.md
git init -b main
git add .
git commit -m "FLORA x Claude/ChatGPT MCP starter kit"
git remote add origin https://github.com/supertatsis/flora-mcp-starter.git
git push -u origin main
```

## After pushing (5 minutes, matters for discovery)
- Repo **About** → description: `Connect FLORA (50+ AI image/video models) to Claude, ChatGPT, Cursor & Codex via MCP — configs, prompts, recipes`
- Topics: `mcp` `model-context-protocol` `flora` `claude` `chatgpt` `ai-video` `ai-image-generation` `generative-ai` `cursor` `claude-code`
- Website field: `https://refer.flora.ai/Tatiana`
- Settings → enable **Discussions** (Q&A threads get indexed and cited by agents)
- Star it from your own account, pin it on your profile
